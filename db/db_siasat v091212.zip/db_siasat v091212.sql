-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 09, 2012 at 10:43 AM
-- Server version: 5.1.37
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `penilaian`
--

-- --------------------------------------------------------

--
-- Table structure for table `bse`
--

CREATE TABLE IF NOT EXISTS `bse` (
  `bid` tinyint(3) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `singkatan` varchar(10) DEFAULT NULL,
  `url` varchar(50) NOT NULL,
  `id_tingkat` tinyint(4) DEFAULT NULL,
  `info` text,
  PRIMARY KEY (`bid`),
  KEY `id_tingkat` (`id_tingkat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bse`
--


-- --------------------------------------------------------

--
-- Table structure for table `guru`
--

CREATE TABLE IF NOT EXISTS `guru` (
  `gid` int(5) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `nama` varchar(30) NOT NULL,
  `gelar` varchar(10) DEFAULT NULL,
  `nip` int(15) DEFAULT NULL,
  `foto` varchar(50) DEFAULT NULL,
  `alamat` text,
  `kode_pos` varchar(7) DEFAULT NULL,
  `telepon` varchar(15) DEFAULT NULL,
  `jenis` enum('P','W') NOT NULL,
  `lahir_tempat` varchar(15) NOT NULL,
  `lahir_tgl` date NOT NULL,
  `status_menikah` enum('Sudah','Belum') NOT NULL,
  `Agama` int(2) NOT NULL,
  PRIMARY KEY (`gid`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `guru`
--

INSERT INTO `guru` (`gid`, `id_user`, `nama`, `gelar`, `nip`, `foto`, `alamat`, `kode_pos`, `telepon`, `jenis`, `lahir_tempat`, `lahir_tgl`, `status_menikah`, `Agama`) VALUES
(1, NULL, 'Lukman Hakim', NULL, NULL, NULL, 'Pamulang', NULL, '081312341234', 'P', '', '0000-00-00', 'Sudah', 0),
(2, NULL, 'Bidel Napitu', NULL, NULL, NULL, 'Bekasi Timur', NULL, '081312341234', 'P', '', '0000-00-00', 'Sudah', 0),
(3, NULL, 'Yunan S.Pd', NULL, NULL, NULL, 'Palmerah Utara', NULL, '081312341234', 'P', '', '0000-00-00', 'Sudah', 0),
(4, NULL, 'Kalda Putra', NULL, NULL, NULL, 'Tangerang', NULL, '081234567890', 'P', '', '0000-00-00', 'Sudah', 0),
(5, NULL, 'Mochamad Solihin', NULL, NULL, NULL, 'Palmerah Utara', NULL, '081234567890', 'P', '', '0000-00-00', 'Sudah', 0),
(6, NULL, 'Udin', NULL, NULL, NULL, 'Pamulang', NULL, '081234567890', 'P', '', '0000-00-00', 'Sudah', 0),
(10, NULL, 'Suharsih S.Pd', NULL, NULL, NULL, 'Bintaro, Pondok Aren', NULL, '081234567890', 'P', '', '0000-00-00', 'Sudah', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jam`
--

CREATE TABLE IF NOT EXISTS `jam` (
  `jid` tinyint(3) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `jam_masuk` time DEFAULT NULL,
  `jam_keluar` time DEFAULT NULL,
  PRIMARY KEY (`jid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jam`
--


-- --------------------------------------------------------

--
-- Table structure for table `kbm`
--

CREATE TABLE IF NOT EXISTS `kbm` (
  `id_mapel` int(5) NOT NULL,
  `id_guru` int(5) NOT NULL,
  `id_kelas` varchar(5) NOT NULL,
  `id_jam` tinyint(3) NOT NULL,
  `id_ruang` tinyint(3) NOT NULL,
  PRIMARY KEY (`id_mapel`),
  KEY `id_guru` (`id_guru`),
  KEY `id_kelas` (`id_kelas`),
  KEY `id_jam` (`id_jam`),
  KEY `id_ruang` (`id_ruang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kbm`
--


-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `kid` varchar(5) NOT NULL,
  `nama` varchar(10) NOT NULL,
  `id_tingkat` tinyint(4) NOT NULL,
  `kapasitas` tinyint(2) NOT NULL,
  `id_guru` int(5) NOT NULL,
  PRIMARY KEY (`kid`),
  KEY `id_guru` (`id_guru`),
  KEY `id_tingkat` (`id_tingkat`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`kid`, `nama`, `id_tingkat`, `kapasitas`, `id_guru`) VALUES
('7a', 'VII - A', 1, 38, 1),
('7b', 'VII - B', 1, 38, 2),
('7c', 'VII - C', 1, 38, 3),
('8a', 'VIII - A', 2, 38, 2),
('8b', 'VIII - B', 2, 38, 1),
('8c', 'VIII - C', 2, 40, 6),
('9a', 'IX - A', 3, 38, 2);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `lid` int(4) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `info` text,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `logid` int(10) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `id_level` int(2) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `aktif` enum('1','0') NOT NULL,
  `info` tinytext NOT NULL,
  `tertanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`logid`),
  UNIQUE KEY `id_user` (`id_user`),
  KEY `id_level` (`id_level`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `mapel`
--

CREATE TABLE IF NOT EXISTS `mapel` (
  `mid` int(5) NOT NULL AUTO_INCREMENT,
  `nama` varchar(25) NOT NULL,
  `singkatan` varchar(5) NOT NULL,
  `kkm` int(3) NOT NULL,
  `kategori` enum('umum','mulok') NOT NULL,
  `rpp` text,
  `bobot_kd` tinyint(3) DEFAULT NULL,
  `bobot_uts` tinyint(3) DEFAULT NULL,
  `bobot_uas` tinyint(3) DEFAULT NULL,
  `info` text,
  `tertanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`mid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mapel`
--

INSERT INTO `mapel` (`mid`, `nama`, `singkatan`, `kkm`, `kategori`, `rpp`, `bobot_kd`, `bobot_uts`, `bobot_uas`, `info`, `tertanggal`) VALUES
(1, 'Matematika', 'MTK', 75, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(2, 'Bahasa Indonesia', 'IND', 75, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(3, 'Bahasa Inggris', 'ENG', 75, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(4, 'Pend. Agama Islam', 'PAI', 80, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(5, 'Pend. Agama Kristen', 'PAK', 8, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(6, 'Ilmu Pengetahuan Alam', 'IPA', 70, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(7, 'Ilmu Pengetahuan Sosial', 'IPS', 70, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(8, 'Kesenian dan Budaya', 'SBD', 70, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(9, 'Pend. Jasmani Kesehatan ', 'PJK', 70, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(10, 'Pend. Lingkungan Jakarta', 'PLKJ', 75, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(11, 'Kewarganegaraan', 'KWN', 70, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00'),
(13, 'Pend. A. Kristen Katolik', 'PAKK', 75, 'umum', NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `nilai_siswa`
--

CREATE TABLE IF NOT EXISTS `nilai_siswa` (
  `nis` int(10) NOT NULL,
  `id_mapel` int(5) NOT NULL,
  `id_tahun` int(2) NOT NULL,
  `id_semester` int(1) NOT NULL,
  `na` float DEFAULT NULL,
  `nb` float DEFAULT NULL,
  `nc` float DEFAULT NULL,
  `nd` float DEFAULT NULL,
  `ne` float DEFAULT NULL,
  `nf` float DEFAULT NULL,
  `ng` float DEFAULT NULL,
  `nh` float DEFAULT NULL,
  `uts` float DEFAULT NULL,
  `uas` float DEFAULT NULL,
  `lulus` enum('Ya','Tidak') DEFAULT NULL,
  `tertanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`nis`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_tahun` (`id_tahun`),
  KEY `id_semester` (`id_semester`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nilai_siswa`
--


-- --------------------------------------------------------

--
-- Table structure for table `ruang`
--

CREATE TABLE IF NOT EXISTS `ruang` (
  `rid` tinyint(3) NOT NULL,
  `nama` varchar(15) NOT NULL,
  `inventaris` text,
  `tertanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ruang`
--


-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE IF NOT EXISTS `semester` (
  `sid` int(1) NOT NULL AUTO_INCREMENT,
  `nama` varchar(10) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`sid`, `nama`, `status`) VALUES
(1, 'Ganjil', 1),
(2, 'Genap', 0);

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `nis` int(10) NOT NULL,
  `nisn` int(15) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `nama` varchar(30) NOT NULL,
  `foto` varchar(50) DEFAULT NULL,
  `tahun_masuk` year(4) NOT NULL,
  `masuk_kelas` varchar(5) NOT NULL,
  `lahir_tempat` varchar(20) DEFAULT NULL,
  `lahir_tgl` date DEFAULT NULL,
  `alamat` text,
  `telepon` varchar(15) DEFAULT NULL,
  `tinggal_dgn` enum('OT','Wali','Saudara') NOT NULL,
  `jenis` enum('P','W') NOT NULL,
  `tinggi` float NOT NULL,
  `berat` float NOT NULL,
  `sakit_bawaan` varchar(50) NOT NULL,
  `agama` int(2) NOT NULL,
  `kwn` enum('WNI','WNA') NOT NULL,
  `sekolah_asal` varchar(50) NOT NULL,
  `alamat_sekolah_asal` text NOT NULL,
  `tahun_lulus` year(4) NOT NULL,
  `no_ijazah` varchar(25) NOT NULL,
  `ayah_nama` varchar(30) NOT NULL,
  `ayah_ttl` varchar(50) NOT NULL,
  `ayah_kerja` varchar(20) NOT NULL,
  `ayah_hasil` int(10) NOT NULL,
  `ayah_alamat` text NOT NULL,
  `ayah_pendidikan` enum('SD','SMP','SMA','D','S','L') NOT NULL,
  `ibu_nama` varchar(30) NOT NULL,
  `ibu_ttl` varchar(50) NOT NULL,
  `ibu_kerja` varchar(20) NOT NULL,
  `ibu_hasil` int(10) NOT NULL,
  `ibu_alamat` text NOT NULL,
  `ibu_pendidikan` enum('SD','SMP','SMA','D','S','L') NOT NULL,
  PRIMARY KEY (`nis`),
  KEY `id_user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`nis`, `nisn`, `id_user`, `nama`, `foto`, `tahun_masuk`, `masuk_kelas`, `lahir_tempat`, `lahir_tgl`, `alamat`, `telepon`, `tinggal_dgn`, `jenis`, `tinggi`, `berat`, `sakit_bawaan`, `agama`, `kwn`, `sekolah_asal`, `alamat_sekolah_asal`, `tahun_lulus`, `no_ijazah`, `ayah_nama`, `ayah_ttl`, `ayah_kerja`, `ayah_hasil`, `ayah_alamat`, `ayah_pendidikan`, `ibu_nama`, `ibu_ttl`, `ibu_kerja`, `ibu_hasil`, `ibu_alamat`, `ibu_pendidikan`) VALUES
(13907, NULL, NULL, 'ACHMAD ARYADI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13908, NULL, NULL, 'ADI YUSUF PRIBADI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13909, NULL, NULL, 'AGUS SETIAWAN', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13910, NULL, NULL, 'ANIS ARDILA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13911, NULL, NULL, 'ANNISA SABILLAH', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13912, NULL, NULL, 'APRIADI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13913, NULL, NULL, 'AZWAR ADAM', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13914, NULL, NULL, 'DEDDI KURNIAWAN', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13915, NULL, NULL, 'DEWI SORAYA USNANI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13916, NULL, NULL, 'EFI SURYANINGSIH', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13917, NULL, NULL, 'FAHMI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13918, NULL, NULL, 'FIRQI RAJI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13919, NULL, NULL, 'GHAFAR LAHULANA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13920, NULL, NULL, 'HAMKA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13921, NULL, NULL, 'HERI PRASTIO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13922, NULL, NULL, 'LENI YANTY', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13923, NULL, NULL, 'LISA RIYANTI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13924, NULL, NULL, 'MAHFUD TRIONO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13925, NULL, NULL, 'MAHLIGA NURDIANA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13926, NULL, NULL, 'MAILISDA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13928, NULL, NULL, 'ACHMAD ANDI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13929, NULL, NULL, 'ACHMAD BASYORI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13930, NULL, NULL, 'ACHMAD HUZEN', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13931, NULL, NULL, 'AHMAD FADLILLAH', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13932, NULL, NULL, 'ANTON SUSENO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13933, NULL, NULL, 'APRIANA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13934, NULL, NULL, 'APRILIANI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13935, NULL, NULL, 'ARI ASHARI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13936, NULL, NULL, 'ARIE AFRIYANTO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13937, NULL, NULL, 'BUDI WALUYO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13938, NULL, NULL, 'DIAN HANDAYANI OKTAVIANY', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13939, NULL, NULL, 'DIO SAPRUDIN', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13940, NULL, NULL, 'DONA AMELIA PUTRI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13941, NULL, NULL, 'FAHRIZAL AGUS', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13942, NULL, NULL, 'FRANDA ISKANDAR', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13943, NULL, NULL, 'GINANJAR SUTRIMO', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13944, NULL, NULL, 'HADI SUHANDI', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13945, NULL, NULL, 'HERLINA', NULL, 2012, '7a', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13946, NULL, NULL, 'IMAS JUMIATI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13947, NULL, NULL, 'JUMIYATI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13948, NULL, NULL, 'KIKI NUR KHOLIFAH HADI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13949, NULL, NULL, 'LUKMANUL HAKIM', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13950, NULL, NULL, 'LUTFIANSYAH', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13951, NULL, NULL, 'MARWAN', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13952, NULL, NULL, 'MOCHAMAD RISKY', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13953, NULL, NULL, 'M. EKO SEPTO RAHARDJO', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13954, NULL, NULL, 'MUHAMMAD ADAM', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13955, NULL, NULL, 'MUHAMMAD FAIZ RIDWAN', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13956, NULL, NULL, 'MUHAMMAD KHIYA RUNNAS', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13957, NULL, NULL, 'MUHAMMAD SOLEH', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13958, NULL, NULL, 'RAHMAWATI HIDAYAT', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13959, NULL, NULL, 'RAYI FERMITHA BUDI ARTI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13960, NULL, NULL, 'RESTI RATNASARI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13961, NULL, NULL, 'REVINDRA PATRIASA', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13962, NULL, NULL, 'REZA NAHDI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13963, NULL, NULL, 'RIKA WULANDARI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13964, NULL, NULL, 'SARAH ZULFIYANTI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13965, NULL, NULL, 'WARDIANA HANDAYANI', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD'),
(13966, NULL, NULL, 'YULIANTI LARAS', NULL, 2012, '7b', NULL, NULL, NULL, NULL, 'OT', 'P', 0, 0, '', 0, 'WNI', '', '', 0000, '', '', '', '', 0, '', 'SD', '', '', '', 0, '', 'SD');

-- --------------------------------------------------------

--
-- Table structure for table `siswa_absen`
--

CREATE TABLE IF NOT EXISTS `siswa_absen` (
  `id` int(11) NOT NULL,
  `nis` int(11) DEFAULT NULL,
  `id_semester` int(1) DEFAULT NULL,
  `absen` enum('s','i','t','a') DEFAULT NULL,
  `tertanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `nis` (`nis`),
  KEY `id_semester` (`id_semester`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa_absen`
--


-- --------------------------------------------------------

--
-- Table structure for table `siswa_kelas`
--

CREATE TABLE IF NOT EXISTS `siswa_kelas` (
  `id_kelas` varchar(5) NOT NULL,
  `nis` int(10) NOT NULL,
  `id_tahun` int(2) NOT NULL,
  KEY `nis` (`nis`),
  KEY `id_tahun` (`id_tahun`),
  KEY `id_kelas` (`id_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `siswa_kelas`
--


-- --------------------------------------------------------

--
-- Table structure for table `tahun`
--

CREATE TABLE IF NOT EXISTS `tahun` (
  `tid` int(2) NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  `tgl_awal` date NOT NULL,
  `tgl_tengah` date NOT NULL,
  `tgl_akhir` date NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tahun`
--

INSERT INTO `tahun` (`tid`, `nama`, `tgl_awal`, `tgl_tengah`, `tgl_akhir`, `info`) VALUES
(1, '2011 - 2012', '2011-06-01', '2011-12-15', '2012-06-01', 'tahun ajar 2011-2012'),
(2, '2012 - 2013', '2012-06-01', '2012-12-15', '2013-06-01', 'tahun ajar 2012-2013');

-- --------------------------------------------------------

--
-- Table structure for table `tingkat`
--

CREATE TABLE IF NOT EXISTS `tingkat` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tingkat`
--

INSERT INTO `tingkat` (`id`, `nama`) VALUES
(1, '7 (Tujuh)'),
(2, '8 (Delapan)'),
(3, '9 (Sembilan)'),
(4, '10 (Sepuluh)'),
(5, '11 (Sebelas)'),
(6, '12 (Dua Belas)');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bse`
--
ALTER TABLE `bse`
  ADD CONSTRAINT `bse_ibfk_1` FOREIGN KEY (`id_tingkat`) REFERENCES `tingkat` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `guru`
--
ALTER TABLE `guru`
  ADD CONSTRAINT `guru_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `login` (`id_user`) ON UPDATE CASCADE;

--
-- Constraints for table `kbm`
--
ALTER TABLE `kbm`
  ADD CONSTRAINT `kbm_ibfk_1` FOREIGN KEY (`id_guru`) REFERENCES `guru` (`gid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kbm_ibfk_2` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`kid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kbm_ibfk_3` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`mid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kbm_ibfk_4` FOREIGN KEY (`id_jam`) REFERENCES `jam` (`jid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kbm_ibfk_5` FOREIGN KEY (`id_ruang`) REFERENCES `ruang` (`rid`) ON UPDATE CASCADE;

--
-- Constraints for table `kelas`
--
ALTER TABLE `kelas`
  ADD CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`id_guru`) REFERENCES `guru` (`gid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `kelas_ibfk_2` FOREIGN KEY (`id_tingkat`) REFERENCES `tingkat` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `login`
--
ALTER TABLE `login`
  ADD CONSTRAINT `login_ibfk_1` FOREIGN KEY (`id_level`) REFERENCES `level` (`lid`) ON UPDATE CASCADE;

--
-- Constraints for table `nilai_siswa`
--
ALTER TABLE `nilai_siswa`
  ADD CONSTRAINT `nilai_siswa_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `siswa` (`nis`) ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_siswa_ibfk_2` FOREIGN KEY (`id_mapel`) REFERENCES `mapel` (`mid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_siswa_ibfk_3` FOREIGN KEY (`id_tahun`) REFERENCES `tahun` (`tid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `nilai_siswa_ibfk_4` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`sid`) ON UPDATE CASCADE;

--
-- Constraints for table `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `login` (`id_user`) ON UPDATE CASCADE;

--
-- Constraints for table `siswa_absen`
--
ALTER TABLE `siswa_absen`
  ADD CONSTRAINT `siswa_absen_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `siswa` (`nis`) ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_absen_ibfk_2` FOREIGN KEY (`id_semester`) REFERENCES `semester` (`sid`) ON UPDATE CASCADE;

--
-- Constraints for table `siswa_kelas`
--
ALTER TABLE `siswa_kelas`
  ADD CONSTRAINT `siswa_kelas_ibfk_1` FOREIGN KEY (`nis`) REFERENCES `siswa` (`nis`) ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_kelas_ibfk_2` FOREIGN KEY (`id_tahun`) REFERENCES `tahun` (`tid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `siswa_kelas_ibfk_3` FOREIGN KEY (`id_kelas`) REFERENCES `kelas` (`kid`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
